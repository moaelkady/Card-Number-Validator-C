#include <cs50.h>
#include <stdio.h>

int numberofdigits(long long cardnumber);

int main(void)
{
    
    //get card number
    printf("Number: ");
    long long card= get_long_long();


    //get the card number into array
    int digits = numberofdigits(card);
    int list[digits];
    for(int i=0 ; i<digits ; i++)
    {
        list[i] = card%10;
        card /= 10;
    }
  
      
    //duplicate odd numbers
    int doublelist[(digits/2)];
    for(int i=1 , j=0 ; i<digits && j<(digits/2) ; i+=2, j++)
    {
        doublelist[j]=list[i]*2;
    }

    
    //make every number in one digit and get sum
    int oddnumbersum = 0;
    for (int i=0 ; i<(digits/2) ;i++)
    {
        if(doublelist[i]<=9)
        {
            oddnumbersum += doublelist[i];
        }
        else
        {
            for(int j=0 ; j<2 ; j++)
            {
                int x = doublelist[i] % 10;
                oddnumbersum += x;
                doublelist[i] /= 10;
                
            }
        }
    }


    //get even numbers and the sum
    int evennumbersum =0;
    for(int i=0 ; i<digits ; i+=2)
    {
        evennumbersum += list[i]; 
    }
    
    
    //get sum of all
    int sumofall = evennumbersum + oddnumbersum;
    
        
    //check validation and type
    if((sumofall % 10) == 0)
    {
        if( list[digits-1]==3 && ( list[digits-2]==4 || list[digits-2]==7 )  && digits == 15 )
        {
            printf("AMEX\n");
        }
        else if (  list[digits-1]==5 && ( list[digits-2]==1 || list[digits-2]==2 || list[digits-2]==3 || list[digits-2]==4 || list[digits-2]==5 )  && digits == 16 )
        {
            printf("MASTERCARD\n");
        }
        else if ( list[digits-1] == 4 && ( digits == 13 || digits == 16 ) )
        {
            printf("VISA\n");
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }
    
    return 0;
}

//function to get number of digits
int numberofdigits(long long cardnumber)
{
    int n=0;
    while(cardnumber !=0 )
    {
        cardnumber /= 10;
        n++;
    }
    
    return n;
}